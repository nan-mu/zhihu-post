let _dirname = __dirname.replace("\\utils", "")

module.exports = { _dirname, __filename};